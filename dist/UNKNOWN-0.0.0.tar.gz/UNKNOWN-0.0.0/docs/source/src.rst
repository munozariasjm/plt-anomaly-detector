src package
===========

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   src.data
   src.model

Submodules
----------

src.analyze module
------------------

.. automodule:: src.analyze
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src
   :members:
   :undoc-members:
   :show-inheritance:
