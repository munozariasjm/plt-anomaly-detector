src.model package
=================

Submodules
----------

src.model.detectors module
--------------------------

.. automodule:: src.model.detectors
   :members:
   :undoc-members:
   :show-inheritance:

src.model.preprocessor module
-----------------------------

.. automodule:: src.model.preprocessor
   :members:
   :undoc-members:
   :show-inheritance:

src.model.searcher module
-------------------------

.. automodule:: src.model.searcher
   :members:
   :undoc-members:
   :show-inheritance:

Module contents
---------------

.. automodule:: src.model
   :members:
   :undoc-members:
   :show-inheritance:
